# Reglas de negocio y decisiones

Revisado: 2026-09-06. Esta versión corrige BUSINESS_RULES.md anterior, que describía como "bloqueado" varias reglas que el código ya resuelve. Cada punto indica dónde vive la implementación.

## Implementadas como cálculo puro

Promediar períodos dentro de cada fuente y sumar esos promedios. Restar gastos, multiplicar disponible por FACTOR_CAPACIDAD recibido de política. Ratios con ingreso cero son NULL (`CreditFinancialAnalysisEngine`).

DSL: comparaciones numéricas =, !=, >, >=, <, <=; igualdad/desigualdad de texto y booleanos; AND/OR mediante `{"operador":"AND","condiciones":[...]}`. Campo contra valor o comparar_con; campos ausentes/NULL, operadores desconocidos, propiedades desconocidas y JSON inválido producen error. Límites de tamaño, profundidad y nodos. Acción inicial GENERAR_ALERTA con resultado explícito (`RuleEngine`).

## Ya resueltas en código (antes descritas como bloqueadas)

- **Redondeo**: `AnalysisDecisions.Money` redondea importes a 2 decimales y `Ratio` a 8 decimales, ambos "away from zero", antes de evaluar cuota compatible (`AnalysisDecisions.Snapshot`).
- **Moneda**: MAPAN no convierte. `CreditAnalysisRepository.ExecuteAsync` rechaza el análisis si alguna fuente de ingreso está en una moneda distinta a la de la empresa.
- **Obligaciones con datos faltantes**: se rechaza el análisis si falta saldo o cuota confirmados; nunca se asumen cero.
- **Transiciones de aprobación/rechazo/devolución**: implementadas en `WorkflowRepository.DecideAsync`, con conteo de aprobaciones requeridas por paso y verificación de rol/permiso.
- **Precedencia de recomendaciones y resultado por defecto**: `AnalysisDecisions.Recommend` ordena por severidad y prioridad; si el grupo más severo tiene resultados distintos, usa REVISION_ADICIONAL; sin reglas aplicables, usa compatible/no compatible según capacidad de pago. Nunca aprueba automáticamente (`RequiereRevisionHumana=true` siempre).
- **Cuota estimada**: no se calcula con fórmula de amortización; se exige el dato confirmado en la solicitud antes de ejecutar el análisis.
- **Requisitos documentales**: si la política define DOCUMENTOS_REQUERIDOS, se valida que estén adjuntos antes de completar el análisis.
- **Actividad principal para antigüedad**: si no hay exactamente una actividad marcada principal con fecha de inicio válida, `antiguedad_actividad_meses` queda NULL y se genera una alerta amarilla; no se infiere.
- **MFA**: si el usuario tiene MFA habilitado, el login se rechaza (`ApplicationError.Configuration`); nunca se omite el segundo factor.
- **Vigencia de obligaciones / creditos_activos**: decidido 2026-09-06. `obligacion.estado` admite VIGENTE, CANCELADA, CASTIGADA, REESTRUCTURADA; VIGENTE y REESTRUCTURADA cuentan como crédito activo (`AnalysisDecisions.ActiveDebtCount`). El análisis rechaza obligaciones con un estado fuera de ese catálogo. Ver docs/PENDING_DATABASE_CHANGES.md para el CHECK constraint propuesto (no ejecutado).

## Decidido: permanecen sin calcular

- `estabilidad_ingresos_score` e `historial_interno_score`: decidido 2026-09-06 que quedan NULL indefinidamente en `vector_caracteristicas`. El modelo predictivo entrenado aparte puede traer su propio scoring interno sin depender de estas columnas; MAPAN no fabrica una fórmula. Si en el futuro se define una, se agrega en `AnalysisDecisions`.

## Bloqueos de negocio pendientes

No se identifican bloqueos adicionales sobre el flujo de análisis/aprobación en esta revisión. Lo que falta para ML es exclusivamente el artefacto entrenado con datos reales (ver ITERATION_REPORT.md, sección "Lo que falta específicamente para ML") y, aparte del flujo de crédito, los módulos aún TODO/PARTIAL/BLOCKED de IMPLEMENTATION_PLAN.md (préstamos/desempeño, auditoría con filtros, informe final) que no dependen de decisiones de negocio sino de implementación.
