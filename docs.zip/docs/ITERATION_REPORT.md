﻿# Entrega de continuación — 2026-09-06

## Implementado en esta iteración

- Auditoría en vivo de 48 tablas y configuración crediticia mediante transacciones READ ONLY.
- Inicio con CTA Nuevo análisis y enlaces directos a expedientes.
- Nuevo expediente guiado con cinco secciones: operación, documentos, datos económicos, validación y resumen.
- Captura/corrección de actividades, fuentes, períodos, gastos y obligaciones usando los endpoints existentes. Búsqueda de clientes en el alta.
- Carga múltiple con drag & drop, progreso por archivos procesados, errores individuales, descarga autenticada y creación de nuevas versiones. El progreso no representa porcentaje de bytes enviados.
- Consulta de extracción disponible e historial completo de validaciones manuales; sin OCR ficticio ni transferencia automática de valores al expediente económico.
- Administración de usuarios, roles y asignaciones con permisos reales, confirmación y lectura previa de asignaciones.
- Límites HTTP de carga alineados con Storage:MaxBytes.
- Arranque local sin dependencia de escritura en Windows Event Log ni claves DPAPI de otra cuenta. Producción mantiene HTTPS.
- Mapeo EF que conserva booleanos explícitos en INSERT, incluso ante DEFAULT true de PostgreSQL; sin cambio de esquema.

## Rutas frontend

| Ruta | Uso |
|---|---|
| /login | Autenticación y empresa |
| / | Bandeja de solicitudes recientes |
| /nuevo-analisis | Alta de solicitud y acceso al expediente |
| /solicitudes | Listado y borradores |
| /solicitudes/:id/expediente | Documentos, economía, validación y resumen |
| /clientes | Clientes |
| /productos | Productos |
| /administracion/seguridad | Usuarios, roles y permisos |

## Endpoints nuevos

- GET /api/documentos/{id}/revision
- POST /api/documentos/{id}/versiones (multipart: archivo)
- GET /api/seguridad/usuarios/{id}/roles
- GET /api/seguridad/roles/{id}/permisos

Se reutilizan /api/auth, /api/empresas, /api/organizacion, /api/clientes, /api/productos, /api/solicitudes, /api/solicitudes/{id}/expediente, /api/documentos y /api/seguridad. Los contratos y métodos completos están en /openapi/v1.json al ejecutar Development.

## Verificación

- dotnet restore y dotnet build: correctos, sin errores ni warnings de compilación.
- dotnet test: 46 pruebas correctas (22 Domain y 24 Application), incluida regresión de booleanos.
- npm.cmd install y npm.cmd run build: correctos. npm informó cuatro scripts de instalación pendientes de aprobación; el build no necesitó habilitarlos.
- FastAPI: 3 pruebas correctas, sin predicción fabricada.
- Arranque real de API en puerto temporal 5207: /health y /health/ready 200, /openapi/v1.json 200; consulta de clientes y revisión documental sin token 401. Proceso temporal detenido al finalizar.
- Sin prueba automatizada de navegador ni prueba transaccional PostgreSQL de carga/versionado. Las pruebas de aislamiento usan EF InMemory; el test físico contrasta los metadatos reales capturados.

## Pendientes y bloqueos

No se alcanzó el objetivo de dejar MAPAN terminado salvo ML.

La base real contiene una política, una versión, FACTOR_CAPACIDAD y una regla CUOTA_SUPERA_CAPACIDAD con resultado REVISION_ADICIONAL. No hay modelos ni rutas de aprobación. No se encontró resultado por defecto ni resolución de recomendaciones contradictorias. Continúan las decisiones documentadas sobre redondeo, mensualización, estados de obligaciones, transiciones y desembolso.

Todavía falta implementar administración de políticas/versiones/reglas, orquestador transaccional, snapshots y vectores persistidos, recomendación, resultado e informe, workflow, cartera/desempeño, consulta de auditoría e interfaces de integraciones/modelos. El catálogo de permisos de estos módulos también requiere configuración; su ausencia no implica necesidad de cambiar esquema.

No se cambiaron criterios crediticios, permisos en PostgreSQL ni datos de negocio para simular un flujo exitoso.

## Lo que falta específicamente para ML

1. Dataset real y proceso de construcción con datos autorizados y trazables.
2. Definición formal de objetivo y scores aún no definidos; sin etiquetar arbitrariamente mal pagador.
3. Entrenamiento de candidatos.
4. Evaluación y selección del modelo.
5. Métricas reales y validación de su desempeño.
6. Artefacto entrenado (joblib) con `model.joblib` + `metadata.json` según el contrato de `services/ml-service/app/model_registry.py`.

Los puntos 1-6 son responsabilidad del proceso de entrenamiento externo (datos reales, definición de objetivo, entrenamiento, evaluación); MAPAN no los ejecuta ni los fabrica.

## Continuación — registro de modelos y carga de artefacto (2026-09-06)

- `services/ml-service` ya no devuelve 503 fijo: `ModelRegistry` carga `model.joblib` (scikit-learn/XGBoost/LightGBM, cualquier estimador con `predict_proba`) más `metadata.json` (orden de variables, `umbral_decision`, `positive_class` opcional, bandas de riesgo opcionales) desde el directorio de `MAPAN_ML_MODEL_DIR`. Sin ese directorio o sin ambos archivos, sigue en `NOT_CONFIGURED` — ningún valor fabricado. Explicabilidad vía SHAP (`TreeExplainer`) con degradación silenciosa a `factores: []` si el estimador no es soportado; nunca contribuciones inventadas. 9 pruebas nuevas/actualizadas en `services/ml-service/tests`.
- `riesgo.modelo` / `riesgo.modelo_version` ahora tienen CRUD completo: `Mapan.Application/Modelos`, `Mapan.Infrastructure/Persistence/Repositories/ModeloRepository.cs`, `Mapan.Api/Controllers/ModelosController.cs`. Ciclo de vida de versión con bloqueo de fila (`FOR UPDATE`): BORRADOR→ENTRENADO→VALIDADO→(PRODUCCION|SHADOW)→RETIRADO. Promover a PRODUCCION exige `artefacto_uri`, `umbral_decision` en [0,1] y el Modelo en ACTIVO; rechaza la promoción si ya hay otra versión PRODUCCION vigente en la empresa (evita `CONFIGURACION_ML_AMBIGUA` en el orquestador). El orquestador (`CreditAnalysisRepository.ExecuteAsync`) ya buscaba y llamaba automáticamente el modelo ACTIVO+PRODUCCION con `artefacto_uri`; no se tocó esa lógica.
- Pendiente de acción manual del usuario, no de código: insertar en `seguridad.permiso` los códigos `Modelos:Read` y `Modelos:Manage` (ya mapeados en `appsettings.json:Permissions:Modelos`) y asignarlos a un rol. Es una inserción de datos de catálogo, no DDL; MAPAN no la ejecuta por disciplina de no tocar la base real sin autorización explícita. Sin esa asignación, cualquier usuario recibe 403 al usar `/api/modelos`.
- `dotnet build`/`dotnet test` (46 pruebas) y `pytest services/ml-service/tests` (9 pruebas) verificados tras el cambio.

Ejecución local: LOCAL_RUN.md.

