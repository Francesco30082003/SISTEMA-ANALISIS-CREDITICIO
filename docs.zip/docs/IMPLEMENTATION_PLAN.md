﻿# MAPAN — auditoría de continuación, 2026-09-06

PostgreSQL inspeccionado en vivo mediante transacción READ ONLY: 48 tablas. Sin DDL ni migraciones. Se conserva el trabajo previo sin commit.

| Área | Estado | Evidencia / pendiente |
|---|---|---|
| Esquema y mapeos | DONE | Inspector real y prueba de columnas, tipos y nulabilidad |
| Login, selección de empresa, JWT | DONE | Servicios, endpoints, guards y pruebas existentes |
| Aislamiento tenant | PARTIAL | Pruebas de clientes, membresías y roles; falta integración PostgreSQL exhaustiva |
| Clientes y productos | DONE | Backend y pantallas existentes |
| Solicitudes | PARTIAL | Alta, borrador y documentación; faltan transiciones crediticias definidas |
| Captura económica | PARTIAL | Backend y captura/corrección guiada de actividades, fuentes, períodos, gastos y obligaciones; mensualización sin definir |
| Documentos | PARTIAL | Storage seguro, carga múltiple, descarga, nuevas versiones y consulta de revisiones implementados; faltan requisitos documentales configurados y prueba PostgreSQL transaccional |
| OCR / buró | BLOCKED | Contratos disponibles; faltan proveedores reales y credenciales. Captura manual permitida |
| Motor financiero / DSL | DONE | Cálculo puro y 22 pruebas Domain; no equivale a análisis persistido |
| Políticas | TODO | Entidades/mapeos existentes; faltan casos de uso, endpoints y editor |
| Orquestador / snapshots / vector | BLOCKED | Redondeo, períodos y obligaciones sin definir; permisos pendientes |
| Recomendación sin ML | BLOCKED | Falta precedencia y resultado por defecto; no aprobar automáticamente |
| Resultado / informe | TODO | Depende de ejecución persistida |
| ML | PARTIAL | Orquestación, carga de artefacto joblib+SHAP y CRUD de riesgo.modelo/modelo_version listos (ver ITERATION_REPORT.md); falta el artefacto real entrenado con datos reales y la fila de permisos Modelos:* en la BD |
| Workflow opcional | BLOCKED | Transiciones y autorizaciones pendientes; existen entidades |
| Préstamos / desempeño | BLOCKED | Autorización y requisitos de desembolso sin definir; existen entidades |
| Usuarios / roles | DONE | Backend y UI de creación, consulta y asignaciones con permisos reales |
| Auditoría | PARTIAL | AuditWriter en casos existentes; falta consulta con filtros y autorización |
| UX | PARTIAL | Inicio orientado al trabajo, nuevo análisis y expediente de cinco secciones; ejecución e informe pendientes |
| Validación base | DONE | dotnet restore/build; 46 tests .NET y 3 Python pasan; npm.cmd install/build correctos; health/readiness 200 y rutas sin sesión 401 |

## Bloqueos de autorización comprobados

El catálogo real contiene 15 permisos: Clientes, Productos, Solicitudes, Documentos y Seguridad:Manage. No hay permisos para políticas, análisis, alertas, auditoría, préstamos ni workflow. No convertir permisos básicos en autoridad crediticia sin definición. No se insertaron permisos ni se cambiaron asignaciones.

Decisiones crediticias pendientes: BUSINESS_RULES.md. No afirmar que solo falta ML mientras haya módulos TODO/PARTIAL/BLOCKED. Compilar no sustituye una demostración integral con PostgreSQL.

## Entrega y ejecución

Detalle verificable, endpoints, rutas y límites: ITERATION_REPORT.md. Instrucciones: LOCAL_RUN.md. No se completó el objetivo integral; quedan implementaciones pendientes además de los bloqueos de negocio y ML.

